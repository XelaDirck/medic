/* ============================================
   MEDISYMEX - JS modular para ADMIN
   Archivo sugerido: ../JS/dashboard_admin.js
============================================ */

/* ========= Datos DEMO (simulados) ========= */

const adminDemoData = {
  resumen: {
    citasHoy: 18,
    pacientesActivos: 240,
    medicos: 12,
    ocupacionAgenda: 78
  },
  usuarios: [
    {
      nombre: "Dr. Juan Pérez",
      rol: "medico",
      correo: "juan.perez@medisymex.com",
      estado: "activo"
    },
    {
      nombre: "Dra. Ana Gómez",
      rol: "medico",
      correo: "ana.gomez@medisymex.com",
      estado: "activo"
    },
    {
      nombre: "María López",
      rol: "recepcionista",
      correo: "maria.lopez@medisymex.com",
      estado: "activo"
    },
    {
      nombre: "Paciente Demo",
      rol: "paciente",
      correo: "paciente.demo@medisymex.com",
      estado: "activo"
    },
    {
      nombre: "Usuario Bloqueado",
      rol: "paciente",
      correo: "bloqueado@medisymex.com",
      estado: "bloqueado"
    }
  ],
  actividades: [
    "Se creó el usuario 'Dra. Ana Gómez'.",
    "Se actualizó la configuración de agenda.",
    "Se generó reporte de citas del mes.",
    "Se activó el envío de recordatorios por correo."
  ],
  alertas: [
    "Hay 5 citas sin médico asignado.",
    "Existen 2 usuarios con contraseña temporal.",
    "Hay recordatorios de cita que no se han podido enviar (revisar correo)."
  ],
  reglasAgenda: [
    "Máximo 20 citas por día por médico.",
    "Bloquear agendar menos de 2 horas antes de la cita.",
    "Permitir overbooking máximo de 1 cita por franja."
  ],
  auditoria: [
    {
      fecha: "2025-11-20 09:15",
      usuario: "Administrador",
      rol: "Admin",
      accion: "Actualizó configuración de agenda",
      detalle: "Duración de cita de 20 a 30 min"
    },
    {
      fecha: "2025-11-19 16:40",
      usuario: "María López",
      rol: "Recepcionista",
      accion: "Creó paciente",
      detalle: "Paciente: Juan Hernández"
    },
    {
      fecha: "2025-11-18 11:10",
      usuario: "Administrador",
      rol: "Admin",
      accion: "Creó usuario",
      detalle: "Usuario: Dra. Ana Gómez"
    }
  ]
};

/* ========= Utilidad simple para texto estado ========= */
function getEstadoBadgeClass(estado) {
  switch (estado) {
    case "activo": return "text-bg-success";
    case "inactivo": return "text-bg-secondary";
    case "bloqueado": return "text-bg-danger";
    default: return "text-bg-light";
  }
}

/* ============================================
   1) Resumen (dashboard_admin.html)
============================================ */
function initAdminResumen() {
  const kpiCitasHoy = document.getElementById("adminKpiCitasHoy");
  const kpiPacientes = document.getElementById("adminKpiPacientes");
  const kpiMedicos = document.getElementById("adminKpiMedicos");
  const kpiOcupacion = document.getElementById("adminKpiOcupacion");
  const listaActividades = document.getElementById("adminListaActividades");
  const listaAlertas = document.getElementById("adminListaAlertas");

  // Si no estamos en esta vista, salimos
  if (!kpiCitasHoy || !listaActividades || !listaAlertas) return;

  // KPIs
  const r = adminDemoData.resumen;
  kpiCitasHoy.textContent = r.citasHoy;
  kpiPacientes.textContent = r.pacientesActivos;
  kpiMedicos.textContent = r.medicos;
  kpiOcupacion.textContent = r.ocupacionAgenda + "%";

  // Actividades
  listaActividades.innerHTML = "";
  adminDemoData.actividades.forEach(a => {
    const li = document.createElement("li");
    li.className = "list-group-item";
    li.textContent = a;
    listaActividades.appendChild(li);
  });

  // Alertas
  listaAlertas.innerHTML = "";
  adminDemoData.alertas.forEach(a => {
    const li = document.createElement("li");
    li.className = "list-group-item";
    li.textContent = a;
    listaAlertas.appendChild(li);
  });
}

/* ============================================
   2) Usuarios y roles (dashboard_admin_usuarios.html)
============================================ */
function initAdminUsuarios() {
  const kMed = document.getElementById("adminUsrMedicos");
  const kRec = document.getElementById("adminUsrRecepcion");
  const kPac = document.getElementById("adminUsrPacientes");
  const kAct = document.getElementById("adminUsrActivos");
  const tablaUsuarios = document.getElementById("tablaUsuarios");
  const formFiltro = document.getElementById("formFiltroUsuarios");
  const txtFiltro = document.getElementById("filtroUsuarioTexto");
  const selRol = document.getElementById("filtroUsuarioRol");
  const selEstado = document.getElementById("filtroUsuarioEstado");
  const btnAplicar = document.getElementById("btnAplicarFiltroUsuarios");

  if (!tablaUsuarios || !formFiltro) return;

  // Contar por rol / estado
  const medicos = adminDemoData.usuarios.filter(u => u.rol === "medico").length;
  const recep = adminDemoData.usuarios.filter(u => u.rol === "recepcionista").length;
  const pacie = adminDemoData.usuarios.filter(u => u.rol === "paciente").length;
  const activos = adminDemoData.usuarios.filter(u => u.estado === "activo").length;

  kMed && (kMed.textContent = medicos);
  kRec && (kRec.textContent = recep);
  kPac && (kPac.textContent = pacie);
  kAct && (kAct.textContent = activos);

  function renderUsuarios(lista) {
    tablaUsuarios.innerHTML = "";
    if (!lista.length) {
      const tr = document.createElement("tr");
      tr.innerHTML = `
        <td colspan="5" class="text-center text-muted small">
          No se encontraron usuarios con ese filtro.
        </td>`;
      tablaUsuarios.appendChild(tr);
      return;
    }

    lista.forEach(u => {
      const tr = document.createElement("tr");
      tr.innerHTML = `
        <td>${u.nombre}</td>
        <td class="text-capitalize">${u.rol}</td>
        <td>${u.correo}</td>
        <td>
          <span class="badge ${getEstadoBadgeClass(u.estado)} text-capitalize">
            ${u.estado}
          </span>
        </td>
        <td class="text-end">
          <button class="btn btn-sm btn-outline-primary me-1">
            <i class="bi bi-eye"></i>
          </button>
          <button class="btn btn-sm btn-outline-secondary me-1">
            <i class="bi bi-pencil"></i>
          </button>
          <button class="btn btn-sm btn-outline-danger">
            <i class="bi bi-x"></i>
          </button>
        </td>
      `;
      tablaUsuarios.appendChild(tr);
    });
  }

  function aplicarFiltro() {
    const texto = (txtFiltro?.value || "").toLowerCase().trim();
    const rol = selRol?.value || "";
    const estado = selEstado?.value || "";

    const filtrados = adminDemoData.usuarios.filter(u => {
      const matchTexto =
        !texto ||
        u.nombre.toLowerCase().includes(texto) ||
        u.correo.toLowerCase().includes(texto);

      const matchRol = !rol || u.rol === rol;
      const matchEstado = !estado || u.estado === estado;

      return matchTexto && matchRol && matchEstado;
    });

    renderUsuarios(filtrados);
  }

  // Inicial
  renderUsuarios(adminDemoData.usuarios);

  // Eventos
  btnAplicar && btnAplicar.addEventListener("click", e => {
    e.preventDefault();
    aplicarFiltro();
  });

  formFiltro.addEventListener("reset", () => {
    setTimeout(() => renderUsuarios(adminDemoData.usuarios), 0);
  });
}

/* ============================================
   3) Agenda y reglas (dashboard_admin_agenda.html)
============================================ */
function initAdminAgenda() {
  const formAgenda = document.getElementById("formAgendaBase");
  const listaReglas = document.getElementById("listaReglasAgenda");

  if (!formAgenda || !listaReglas) return;

  // Render reglas demo
  listaReglas.innerHTML = "";
  adminDemoData.reglasAgenda.forEach(r => {
    const li = document.createElement("li");
    li.className = "list-group-item";
    li.textContent = r;
    listaReglas.appendChild(li);
  });

  formAgenda.addEventListener("submit", e => {
    e.preventDefault();
  });

  // Botón guardar (demostración)
  const btnGuardar = formAgenda.querySelector("button[type='button']");
  if (btnGuardar) {
    btnGuardar.addEventListener("click", () => {
      console.log("Guardar configuración de agenda (demo)");
      alert("Configuración de agenda guardada (demo).");
    });
  }
}

/* ============================================
   4) Reportes (dashboard_admin_reportes.html)
============================================ */
function initAdminReportes() {
  const form = document.getElementById("formFiltroReportes");
  const tabla = document.getElementById("tablaReportes");

  if (!form || !tabla) return;

  const tbody = tabla.querySelector("tbody");

  function renderReporteDemo() {
    if (!tbody) return;
    tbody.innerHTML = "";

    // Demo: 3 filas
    const demo = [
      { fecha: "2025-11-01", tipo: "citas", desc: "Citas del día", valor: "35" },
      { fecha: "2025-11-01", tipo: "pacientes", desc: "Pacientes nuevos", valor: "5" },
      { fecha: "2025-11-01", tipo: "citas", desc: "Citas canceladas", valor: "3" }
    ];

    demo.forEach(r => {
      const tr = document.createElement("tr");
      tr.innerHTML = `
        <td>${r.fecha}</td>
        <td class="text-capitalize">${r.tipo}</td>
        <td>${r.desc}</td>
        <td>${r.valor}</td>
      `;
      tbody.appendChild(tr);
    });
  }

  const btns = form.querySelectorAll("button");
  btns.forEach(btn => {
    btn.addEventListener("click", e => {
      e.preventDefault();
      if (btn.textContent.toLowerCase().includes("generar")) {
        renderReporteDemo();
      }
      if (btn.textContent.toLowerCase().includes("limpiar")) {
        if (tbody) {
          tbody.innerHTML = `
            <tr>
              <td colspan="4" class="text-center text-muted">
                Genera un reporte para ver los resultados aquí.
              </td>
            </tr>`;
        }
      }
    });
  });
}

/* ============================================
   5) Configuración sistema (dashboard_admin_configuracion.html)
============================================ */
function initAdminConfiguracion() {
  const formClinica = document.getElementById("formClinicaDatos");
  const formPrefs = document.getElementById("formPreferencias");

  if (!formClinica && !formPrefs) return;

  if (formClinica) {
    const btn = formClinica.querySelector("button[type='button']");
    btn && btn.addEventListener("click", () => {
      console.log("Guardar datos de la clínica (demo)");
      alert("Datos de la clínica guardados (demo).");
    });
  }

  if (formPrefs) {
    const btn = formPrefs.querySelector("button[type='button']");
    btn && btn.addEventListener("click", () => {
      console.log("Guardar preferencias del sistema (demo)");
      alert("Preferencias del sistema guardadas (demo).");
    });
  }
}

/* ============================================
   6) Notificaciones (dashboard_admin_notificaciones.html)
============================================ */
function initAdminNotificaciones() {
  const form = document.getElementById("formNotifCanales");
  const lista = document.getElementById("listaNotificacionesAdmin");

  if (!form || !lista) return;

  // Demo: historial vacío por ahora (ya viene un li por defecto)
  const btnGuardar = form.querySelector("button[type='button']");
  btnGuardar && btnGuardar.addEventListener("click", () => {
    console.log("Guardar configuración de notificaciones (demo)");
    alert("Configuración de notificaciones guardada (demo).");
  });
}

/* ============================================
   7) Auditoría (dashboard_admin_auditoria.html)
============================================ */
function initAdminAuditoria() {
  const tabla = document.getElementById("tablaAuditoria");
  if (!tabla) return;

  const tbody = tabla.querySelector("tbody");
  if (!tbody) return;

  tbody.innerHTML = "";

  adminDemoData.auditoria.forEach(reg => {
    const tr = document.createElement("tr");
    tr.innerHTML = `
      <td>${reg.fecha}</td>
      <td>${reg.usuario}</td>
      <td>${reg.rol}</td>
      <td>${reg.accion}</td>
      <td>${reg.detalle}</td>
    `;
    tbody.appendChild(tr);
  });
}

/* ============================================
   8) Perfil (dashboard_admin_perfil.html)
============================================ */
function initAdminPerfil() {
  const form = document.getElementById("formPerfilAdmin");
  const nombreHeader = document.getElementById("adminNombrePerfil");

  if (!form || !nombreHeader) return;

  const nombreInput = form.querySelector("input[type='text']");
  if (nombreInput) {
    // Sincronizar al vuelo el nombre mostrado
    nombreInput.addEventListener("input", () => {
      nombreHeader.textContent = nombreInput.value || "Administrador";
    });
  }

  // Guardar cambios (demo)
  const btn = form.querySelector("button[type='button']");
  btn && btn.addEventListener("click", () => {
    console.log("Guardar perfil admin (demo)");
    alert("Perfil actualizado (demo).");
  });
}

/* ============================================
   AUTO-INICIALIZACIÓN POR PÁGINA
============================================ */
document.addEventListener("DOMContentLoaded", () => {
  initAdminResumen();
  initAdminUsuarios();
  initAdminAgenda();
  initAdminReportes();
  initAdminConfiguracion();
  initAdminNotificaciones();
  initAdminAuditoria();
  initAdminPerfil();
});
