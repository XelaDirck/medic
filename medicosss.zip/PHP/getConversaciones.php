<?php
include 'conexion.php';

$medico_id = $_SESSION['usuario_id'];  // Obtener el ID del médico desde la sesión
$paciente_id = $_GET['paciente_id'];

$query = "SELECT * FROM conversaciones WHERE medico_id = ? AND paciente_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param('ii', $medico_id, $paciente_id);
$stmt->execute();
$result = $stmt->get_result();

$conversaciones = [];
while ($row = $result->fetch_assoc()) {
    $conversaciones[] = $row;
}

echo json_encode($conversaciones);

$stmt->close();
$conn->close();
?>
