<?php
include 'conexion.php';
session_start();

$data = json_decode(file_get_contents('php://input'), true);

$paciente = $data['paciente'];
$medico = $data['medico'];
$fecha = $data['fecha'];
$hora = $data['hora'];
$motivo = $data['motivo'];
$estado = $data['estado'];

$query = "INSERT INTO citas (paciente_nombre, medico_nombre, fecha_cita, hora_cita, motivo, estado, recepcionista_id) VALUES (?, ?, ?, ?, ?, ?, ?)";
$stmt = $conn->prepare($query);
$stmt->bind_param("ssssssi", $paciente, $medico, $fecha, $hora, $motivo, $estado, $_SESSION['usuario_id']);
$stmt->execute();

echo json_encode(['status' => 'success']);

$stmt->close();
$conn->close();
?>

