<?php
include 'conexion.php';
session_start();

$data = json_decode(file_get_contents('php://input'), true);

$nombre = $data['nombre'];
$documento = $data['documento'];
$telefono = $data['telefono'];
$correo = $data['correo'];
$estadoCivil = $data['estadoCivil'];
$nacionalidad = $data['nacionalidad'];
$domicilio = $data['domicilio'];
$medico = $data['medico'];
$etiqueta = $data['etiqueta'];

$query = "INSERT INTO pacientes (nombre, documento, telefono, correo, estado_civil, nacionalidad, domicilio, medico_responsable, etiqueta) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
$stmt = $conn->prepare($query);
$stmt->bind_param("sssssssss", $nombre, $documento, $telefono, $correo, $estadoCivil, $nacionalidad, $domicilio, $medico, $etiqueta);
$stmt->execute();

echo json_encode(['status' => 'success']);

$stmt->close();
$conn->close();
?>
