<?php
session_start();
include 'conexion.php';

/* === CREAR SESION FAMILIAR === */
function crearSesionFamiliar($ID_Familiar, $conexion) {
    // Cerrar sesiones anteriores del mismo administrador
    $conexion->prepare("UPDATE Sesiones_familiares SET Activo = 0 WHERE ID_Familiar = :id")
             ->execute([':id' => $ID_Familiar]);

    // Crear token nuevo
    $Token = bin2hex(random_bytes(32));

    $stmt = $conexion->prepare("INSERT INTO Sesiones_familiares (ID_Familiar, Token) VALUES (:id, :token)");
    $stmt->execute([':id' => $ID_Familiar, ':token' => $Token]);

    // Guardar en sesión PHP
    $_SESSION['loggedin'] = true;
    $_SESSION['ID_Familiar'] = $ID_Familiar;
    $_SESSION['Token_familiar'] = $Token;
}

/* === VERIFICAR SESION FAMILIAR === */
function verificarSesionFamiliar($conexion) {
    if (!isset($_SESSION['ID_Familiar'], $_SESSION['Token_familiar'])) {
        header("Location: ../HTML/login_familiares.html");
        exit;
    }

    $stmt = $conexion->prepare("SELECT * FROM Sesiones_familiares WHERE ID_Familiar = :id AND Token = :token AND Activo = 1");
    $stmt->execute([':id' => $_SESSION['ID_Familiar'], ':token' => $_SESSION['Token_familiar']]);
    $sesion = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$sesion) {
        cerrarSesionFamiliar($conexion);
        header("Location: ../HTML/login_familiares.html");
        exit;
    }
}

/* === CERRAR SESION FAMILIAR === */
function cerrarSesionFamiliar($conexion) {
    if (isset($_SESSION['Token_familiar'])) {
        $stmt = $conexion->prepare("UPDATE Sesiones_familiares SET Activo = 0 WHERE Token = :token");
        $stmt->execute([':token' => $_SESSION['Token_familiar']]);
    }

    session_unset();
    session_destroy();
}
?>
