<?php
include 'conexion.php';

$fecha = $_POST['fecha'];
$hora = $_POST['hora'];
$paciente = $_POST['paciente'];
$motivo = $_POST['motivo'];
$tipo = $_POST['tipo'];
$estado = $_POST['estado'];

$query = "INSERT INTO citas (fecha_cita, hora_cita, paciente_nombre, motivo, tipo, estado, medico_id) 
          VALUES (?, ?, ?, ?, ?, ?, ?)";
$stmt = $conn->prepare($query);
$stmt->bind_param('ssssssi', $fecha, $hora, $paciente, $motivo, $tipo, $estado, $medico_id);
$stmt->execute();

echo json_encode(['status' => 'success']);

$stmt->close();
$conn->close();
?>
