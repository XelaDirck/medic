<?php
include 'conexion.php';

$pacienteId = $_POST['pacienteId'];
$nombre = $_POST['nombre'];
$edad = $_POST['edad'];
$alergias = $_POST['alergias'];

$query = "UPDATE pacientes SET nombre = ?, edad = ?, alergias = ? WHERE paciente_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param('sisi', $nombre, $edad, $alergias, $pacienteId);
$stmt->execute();

echo json_encode(['status' => 'success']);

$stmt->close();
$conn->close();
?>

