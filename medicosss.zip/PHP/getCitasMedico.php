<?php
include 'conexion.php';

$medico_id = $_SESSION['usuario_id'];  // Obtener el ID del médico desde la sesión

$query = "SELECT * FROM citas WHERE medico_id = ? ORDER BY fecha_cita DESC";
$stmt = $conn->prepare($query);
$stmt->bind_param('i', $medico_id);
$stmt->execute();
$result = $stmt->get_result();

$citas = [];
while ($row = $result->fetch_assoc()) {
    $citas[] = $row;
}

echo json_encode($citas);

$stmt->close();
$conn->close();
?>
