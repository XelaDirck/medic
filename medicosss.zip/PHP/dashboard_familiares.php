<?php
include '../PHP/conexion.php';
include '../PHP/sesion_familiares.php';

// Esto valida la sesión activa
verificarSesionFamiliar($conexion);
?>


<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Flemming - Dashboard</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="styles.css">
    
</head>
<body>
    <div class="d-flex flex-column flex-lg-row min-vh-100">
        <!-- Sidebar -->
        <nav id="sidebar" class="d-flex flex-column p-3">
            <a href="#" class="navbar-brand mb-4">Flemming</a>
            <ul class="nav nav-pills flex-column mb-auto">
                <li class="nav-item"><a href="#" class="nav-link active">Inicio</a></li>
                <li><a href="#" class="nav-link">Pacientes</a></li>
                <li><a href="#" class="nav-link">Citas</a></li>
                <li><a href="#" class="nav-link">Reportes</a></li>
                <li><a href="#" class="nav-link">Configuración</a></li>
            </ul>
            <hr>
            <div class="mt-auto">
                <a href="login_general.html" class="nav-link">Cerrar sesión</a>
            </div>
        </nav>

        <!-- Main Content -->
        <div id="main-content" class="flex-grow-1">
            <!-- Navbar superior -->
            <nav class="navbar navbar-expand-lg shadow-sm mb-4">
                <div class="container-fluid">
                    <span class="navbar-text fw-bold text-white">Bienvenido, <span id="username">Usuario</span></span>
                </div>
            </nav>

            <!-- Dashboard Cards -->
            <div class="row g-4">
                <div class="col-md-6 col-lg-3">
                    <div class="card shadow-sm p-3 text-center">
                        <h5 class="card-title">Pacientes Activos</h5>
                        <p class="card-text fs-4">120</p>
                        <a href="#" class="btn btn-success w-100">Ver Pacientes</a>
                    </div>
                </div>
                <div class="col-md-6 col-lg-3">
                    <div class="card shadow-sm p-3 text-center">
                        <h5 class="card-title">Citas Hoy</h5>
                        <p class="card-text fs-4">15</p>
                        <a href="#" class="btn btn-success w-100">Ver Citas</a>
                    </div>
                </div>
                <div class="col-md-6 col-lg-3">
                    <div class="card shadow-sm p-3 text-center">
                        <h5 class="card-title">Reportes Pendientes</h5>
                        <p class="card-text fs-4">3</p>
                        <a href="#" class="btn btn-success w-100">Ver Reportes</a>
                    </div>
                </div>
                <div class="col-md-6 col-lg-3">
                    <div class="card shadow-sm p-3 text-center">
                        <h5 class="card-title">Mensajes</h5>
                        <p class="card-text fs-4">5</p>
                        <a href="#" class="btn btn-success w-100">Leer Mensajes</a>
                    </div>
                </div>
            </div>

            <!-- Main Dashboard Content -->
            <section class="mt-5">
                <h3 class="fw-bold mb-3">Resumen General</h3>
                <p class="text-muted">Aquí podrás visualizar la información más relevante de tu área de trabajo, gestionar pacientes, citas, reportes y acceder a la configuración de tu cuenta.</p>
            </section>
        </div>
    </div>

    <!-- Footer -->
    <footer>
        &copy; 2025 Clínica Flemming | <a href="#">Política de Privacidad</a> | <a href="#">Términos de Uso</a>
    </footer>

    <!-- Bootstrap JS Bundle -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
