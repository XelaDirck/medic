<?php
session_start();
include 'conexion.php';

/* === CREAR SESION FAMILIAR === */
function crearSesionPaciente($ID_Paciente, $conexion) {
    // Cerrar sesiones anteriores del mismo administrador
    $conexion->prepare("UPDATE Sesiones_pacientes SET Activo = 0 WHERE ID_Paciente = :id")
             ->execute([':id' => $ID_Paciente]);

    // Crear token nuevo
    $Token = bin2hex(random_bytes(32));

    $stmt = $conexion->prepare("INSERT INTO Sesiones_pacientes (ID_Paciente, Token) VALUES (:id, :token)");
    $stmt->execute([':id' => $ID_Paciente, ':token' => $Token]);

    // Guardar en sesión PHP
    $_SESSION['loggedin'] = true;
    $_SESSION['ID_Paciente'] = $ID_Paciente;
    $_SESSION['Token_paciente'] = $Token;
}

/* === VERIFICAR SESION FAMILIAR === */
function verificarSesionPaciente($conexion) {
    if (!isset($_SESSION['ID_Paciente'], $_SESSION['Token_paciente'])) {
        header("Location: ../HTML/login_pacientes.html");
        exit;
    }

    $stmt = $conexion->prepare("SELECT * FROM Sesiones_pacientes WHERE ID_Paciente = :id AND Token = :token AND Activo = 1");
    $stmt->execute([':id' => $_SESSION['ID_Paciente'], ':token' => $_SESSION['Token_paciente']]);
    $sesion = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$sesion) {
        cerrarSesionPaciente($conexion);
        header("Location: ../HTML/login_pacientes.html");
        exit;
    }
}

/* === CERRAR SESION FAMILIAR === */
function cerrarSesionPaciente($conexion) {
    if (isset($_SESSION['Token_paciente'])) {
        $stmt = $conexion->prepare("UPDATE Sesiones_pacientes SET Activo = 0 WHERE Token = :token");
        $stmt->execute([':token' => $_SESSION['Token_paciente']]);
    }

    session_unset();
    session_destroy();
}
?>
