<?php
include 'conexion.php';
session_start();

$recepcionista_id = $_SESSION['usuario_id'];

$resumen = [
  'citasHoy' => 12,
  'pacientesEnEspera' => 4,
  'citasPorConfirmar' => 3,
  'citasCanceladas' => 1
];

echo json_encode($resumen);
?>
