<?php
session_start();
include 'conexion.php';

/* === CREAR SESIÓN ADMINISTRADOR === */
function crearSesionRecepcionista($ID_Recepcionista, $conexion) {
    // Cerrar sesiones anteriores del mismo administrador
    $conexion->prepare("UPDATE Sesiones_recepcionistas SET Activo = 0 WHERE ID_Recepcionista = :id")
             ->execute([':id' => $ID_Recepcionista]);

    // Crear token nuevo
    $Token = bin2hex(random_bytes(32));

    $stmt = $conexion->prepare("INSERT INTO Sesiones_recepcionistas (ID_Recepcionista, Token) VALUES (:id, :token)");
    $stmt->execute([':id' => $ID_Recepcionista, ':token' => $Token]);

    // Guardar en sesión PHP
    $_SESSION['loggedin'] = true;
    $_SESSION['ID_Recepcionista'] = $ID_Recepcionista;
    $_SESSION['Token_recepcionista'] = $Token;
}

/* === VERIFICAR SESIÓN ADMINISTRADOR === */
function verificarSesionRecepcionista($conexion) {
    if (!isset($_SESSION['ID_Recepcionista'], $_SESSION['Token_recepcionista'])) {
        header("Location: ../HTML/login_recepcionistas.html");
        exit;
    }

    $stmt = $conexion->prepare("SELECT * FROM Sesiones_recepcionistas WHERE ID_Recepcionista = :id AND Token = :token AND Activo = 1");
    $stmt->execute([':id' => $_SESSION['ID_Recepcionista'], ':token' => $_SESSION['Token_recepcionista']]);
    $sesion = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$sesion) {
        cerrarSesionRecepcionista($conexion);
        header("Location: ../HTML/login_recepcionistas.html");
        exit;
    }
}

/* === CERRAR SESIÓN ADMINISTRADOR === */
function cerrarSesionRecepcionista($conexion) {
    if (isset($_SESSION['Token_recepcionista'])) {
        $stmt = $conexion->prepare("UPDATE Sesiones_recepcionistas SET Activo = 0 WHERE Token = :token");
        $stmt->execute([':token' => $_SESSION['Token_recepcionista']]);
    }

    session_unset();
    session_destroy();
}
?>
