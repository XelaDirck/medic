<?php
include 'conexion.php';

$mensaje = $_POST['mensaje'];
$pacienteId = $_POST['pacienteId'];

$query = "INSERT INTO mensajes (mensaje, paciente_id, medico_id) VALUES (?, ?, ?)";
$stmt = $conn->prepare($query);
$stmt->bind_param('sii', $mensaje, $pacienteId, $medico_id);
$stmt->execute();

echo json_encode(['status' => 'success']);

$stmt->close();
$conn->close();
?>
