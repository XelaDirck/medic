<?php
include 'conexion.php';

$medico_id = $_SESSION['usuario_id'];  // Obtener el ID del médico desde la sesión

$query = "SELECT 
            COUNT(*) AS citas_hoy, 
            (SELECT COUNT(*) FROM pacientes WHERE medico_id = ?) AS pacientes_activos, 
            (SELECT COUNT(*) FROM resultados WHERE estado = 'pendiente' AND medico_id = ?) AS resultados_pendientes,
            (SELECT COUNT(*) FROM alertas WHERE estado = 'activo' AND medico_id = ?) AS alertas
        ";
$stmt = $conn->prepare($query);
$stmt->bind_param('iii', $medico_id, $medico_id, $medico_id);
$stmt->execute();
$result = $stmt->get_result();
$data = $result->fetch_assoc();

echo json_encode($data);

$stmt->close();
$conn->close();
?>
