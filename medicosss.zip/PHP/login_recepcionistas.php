<?php
session_start();
include __DIR__ . '/conexion.php';
include __DIR__ . '/sesion_recepcionistas.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $usuario = trim($_POST['username'] ?? '');
    $contraseña = $_POST['password'] ?? '';

    if (empty($usuario) || empty($contraseña)) {
        header("Location: ../HTML/login_recepcionistas.html");
        exit;
    }

    try {
        $stmt = $conexion->prepare("SELECT ID, Usuario, Contraseña FROM Recepcionistas WHERE Usuario = :usuario LIMIT 1");
        $stmt->execute([':usuario' => $usuario]);
        $admin = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($admin && password_verify($contraseña, $admin['Contraseña'])) {
            crearSesionRecepcionista($admin['ID'], $conexion);
            $_SESSION['username'] = $admin['Usuario'];
            $_SESSION['rol'] = 'Recepcionista';
            header("Location: dashboard_recepcionistas.php");
            exit;
        } else {
            header("Location: ../HTML/login_recepcionistas.html");
            exit;
        }
    } catch (PDOException $e) {
        // En producción no mostrar detalles
        header("Location: ../HTML/login_recepcionistas.html");
        exit;
    }
} else {
    header("Location: ../HTML/login_recepcionistas.html");
    exit;
}
?>
