<?php
// conexion.php - CONTRASEÑA VACÍA
$host = "localhost";
$port = "3307";
$dbname = "MEDISYMEX";
$user = "root";
$password = "";  // CONTRASEÑA VACÍA

try {
    $dsn = "mysql:host=$host;port=$port;dbname=$dbname;charset=utf8mb4";
    
    $conexion = new PDO($dsn, $user, $password, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false
    ]);
    
} catch (PDOException $e) {
    // Solo para desarrollo - en producción usa un mensaje genérico
    die("Error de conexión a la base de datos: " . $e->getMessage());
}
?>