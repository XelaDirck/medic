<?php
include 'conexion.php';

$role = $_GET['role'];  // Obtener el rol desde la URL

if ($role == 'medico') {
    $query = "SELECT * FROM citas WHERE medico_id = ? ORDER BY fecha_cita";
} else {
    // Lógica para otros roles
}
$stmt = $conn->prepare($query);
$stmt->bind_param('i', $medico_id);
$stmt->execute();
$result = $stmt->get_result();

$citas = [];
while ($row = $result->fetch_assoc()) {
    $citas[] = $row;
}

echo json_encode($citas);

$stmt->close();
$conn->close();
?>
