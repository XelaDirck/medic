<?php
include 'conexion.php';
session_start();

$recepcionista_id = $_SESSION['usuario_id'];

// Simulando datos de pacientes en espera
$pacientes = [
  ['nombre' => 'Juan Pérez', 'motivo' => 'Consulta general', 'turno' => 1],
  ['nombre' => 'Ana Gómez', 'motivo' => 'Control', 'turno' => 2],
  ['nombre' => 'Paciente Demo', 'motivo' => 'Estudios', 'turno' => 3]
];

echo json_encode($pacientes);
?>

