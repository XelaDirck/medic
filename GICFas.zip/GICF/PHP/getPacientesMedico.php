<?php
include 'conexion.php';

$medico_id = $_SESSION['usuario_id'];  // Obtener el ID del médico desde la sesión

$query = "SELECT * FROM pacientes WHERE medico_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param('i', $medico_id);
$stmt->execute();
$result = $stmt->get_result();

$pacientes = [];
while ($row = $result->fetch_assoc()) {
    $pacientes[] = $row;
}

echo json_encode($pacientes);

$stmt->close();
$conn->close();
?>
