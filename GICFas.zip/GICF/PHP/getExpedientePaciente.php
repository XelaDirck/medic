<?php
include 'conexion.php';
session_start();

$paciente_id = $_GET['paciente_id'];

$query = "SELECT * FROM registros_medicos WHERE paciente_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $paciente_id);
$stmt->execute();
$result = $stmt->get_result();

$expediente = $result->fetch_assoc();

echo json_encode($expediente);

$stmt->close();
$conn->close();
?>
