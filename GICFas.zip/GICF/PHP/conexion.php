<?php
// Datos de conexión
$host = "localhost:3307";
$user = "root";
$password = "@ R00t' T35t' @"; 
$dbname = "MEDISYMEX";

try {
    $conexion = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $user, $password);
    
    // Configuración de errores
    $conexion->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    echo "Conexión exitosa a la base de datos $dbname";  // Mensaje de éxito
    
} catch (PDOException $e) {
    die("Error de conexión PDO: " . $e->getMessage());  // Mostrar error si falla la conexión
}
