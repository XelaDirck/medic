<?php
include 'conexion.php';
session_start();

$paciente_id = $_SESSION['usuario_id'];

// Consultar datos dinámicos para el paciente
$resumen = [
  'nombre' => 'Juan Pérez',
  'citasProximas' => 2,  // Esto se obtendría de la base de datos con una consulta adecuada
  'ultEstudio' => 'Radiografía de tórax', // Igualmente, esto viene de los estudios del paciente
  'tratamiento' => 'Losartán 50mg', // Esto se obtiene de los tratamientos activos
  'mensajes' => 4  // Mensajes nuevos
];

echo json_encode($resumen);
?>
