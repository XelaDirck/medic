<?php
include 'conexion.php';
session_start();

$data = json_decode(file_get_contents('php://input'), true);

$mensaje = $data['mensaje'];

$query = "INSERT INTO mensajes (contenido, recepcionista_id) VALUES (?, ?)";
$stmt = $conn->prepare($query);
$stmt->bind_param("si", $mensaje, $_SESSION['usuario_id']);
$stmt->execute();

echo json_encode(['status' => 'success']);

$stmt->close();
$conn->close();
?>
