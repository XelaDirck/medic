<?php
include 'conexion.php';
session_start();

$paciente_id = $_SESSION['usuario_id'];

$query = "SELECT * FROM citas WHERE paciente_id = ? ORDER BY fecha_cita DESC";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $paciente_id);
$stmt->execute();
$result = $stmt->get_result();

$citas = [];
while ($row = $result->fetch_assoc()) {
    $citas[] = $row;
}

echo json_encode($citas);

$stmt->close();
$conn->close();
?>
