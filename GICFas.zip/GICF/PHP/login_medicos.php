<?php
session_start();
include __DIR__ . '/conexion.php';
include __DIR__ . '/sesion_medicos.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $usuario = trim($_POST['username'] ?? '');
    $contraseña = $_POST['password'] ?? '';

    if (empty($usuario) || empty($contraseña)) {
        header("Location: ../HTML/login_medicos.html");
        exit;
    }

    try {
        $stmt = $conexion->prepare("SELECT ID, Usuario, Contraseña FROM Medicos WHERE Usuario = :usuario LIMIT 1");
        $stmt->execute([':usuario' => $usuario]);
        $medico = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($medico && password_verify($contraseña, $medico['Contraseña'])) {
            // Crear sesión correctamente para médicos
            crearSesionMedico($medico['ID'], $conexion);
            $_SESSION['username'] = $medico['Usuario'];
            $_SESSION['rol'] = 'Medico';

            header("Location: dashboard_medicos.php");
            exit;
        } else {
            header("Location: ../HTML/login_medicos.html");
            exit;
        }
    } catch (PDOException $e) {
        // En producción no mostrar detalles
        header("Location: ../HTML/login_medicos.html");
        exit;
    }
} else {
    header("Location: ../HTML/login_medicos.html");
    exit;
}
?>
