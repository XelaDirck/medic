<?php
session_start();
include 'conexion.php';

/* === CREAR SESIÓN ADMINISTRADOR === */
function crearSesionAdministrador($ID_Administrador, $conexion) {
    // Cerrar sesiones anteriores del mismo administrador
    $conexion->prepare("UPDATE Sesiones_administradores SET Activo = 0 WHERE ID_Administrador = :id")
             ->execute([':id' => $ID_Administrador]);

    // Crear token nuevo
    $Token = bin2hex(random_bytes(32));

    $stmt = $conexion->prepare("INSERT INTO Sesiones_administradores (ID_Administrador, Token) VALUES (:id, :token)");
    $stmt->execute([':id' => $ID_Administrador, ':token' => $Token]);

    // Guardar en sesión PHP
    $_SESSION['loggedin'] = true;
    $_SESSION['ID_Administrador'] = $ID_Administrador;
    $_SESSION['Token_Administrador'] = $Token;
}

/* === VERIFICAR SESIÓN ADMINISTRADOR === */
function verificarSesionAdministrador($conexion) {
    if (!isset($_SESSION['ID_Administrador'], $_SESSION['Token_Administrador'])) {
        header("Location: ../HTML/login_administradores.html");
        exit;
    }

    $stmt = $conexion->prepare("SELECT * FROM Sesiones_administradores WHERE ID_Administrador = :id AND Token = :token AND Activo = 1");
    $stmt->execute([':id' => $_SESSION['ID_Administrador'], ':token' => $_SESSION['Token_Administrador']]);
    $sesion = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$sesion) {
        cerrarSesionAdministrador($conexion);
        header("Location: ../HTML/login_administradores.html");
        exit;
    }
}

/* === CERRAR SESIÓN ADMINISTRADOR === */
function cerrarSesionAdministrador($conexion) {
    if (isset($_SESSION['Token_Administrador'])) {
        $stmt = $conexion->prepare("UPDATE Sesiones_administradores SET Activo = 0 WHERE Token = :token");
        $stmt->execute([':token' => $_SESSION['Token_Administrador']]);
    }

    session_unset();
    session_destroy();
}
?>
