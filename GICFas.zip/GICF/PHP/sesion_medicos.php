<?php
session_start();
include 'conexion.php';

/* === CREAR SESIÓN ADMINISTRADOR === */
function crearSesionMedico($ID_Medico, $conexion) {
    // Cerrar sesiones anteriores del mismo administrador
    $conexion->prepare("UPDATE Sesiones_medicos SET Activo = 0 WHERE ID_Medico = :id")
             ->execute([':id' => $ID_Medico]);

    // Crear token nuevo
    $Token = bin2hex(random_bytes(32));

    $stmt = $conexion->prepare("INSERT INTO Sesiones_medicos (ID_Medico, Token) VALUES (:id, :token)");
    $stmt->execute([':id' => $ID_Medico, ':token' => $Token]);

    // Guardar en sesión PHP
    $_SESSION['loggedin'] = true;
    $_SESSION['ID_Medico'] = $ID_Medico;
    $_SESSION['Token_Medico'] = $Token;
}

/* === VERIFICAR SESIÓN ADMINISTRADOR === */
function verificarSesionMedico($conexion) {
    if (!isset($_SESSION['ID_Medico'], $_SESSION['Token_Medico'])) {
        header("Location: ../HTML/login_medicos.html");
        exit;
    }

    $stmt = $conexion->prepare("SELECT * FROM Sesiones_medicos WHERE ID_Medico = :id AND Token = :token AND Activo = 1");
    $stmt->execute([':id' => $_SESSION['ID_Medico'], ':token' => $_SESSION['Token_Medico']]);
    $sesion = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$sesion) {
        cerrarSesionMedico($conexion);
        header("Location: ../HTML/login_medicos.html");
        exit;
    }
}

/* === CERRAR SESIÓN ADMINISTRADOR === */
function cerrarSesionMedico($conexion) {
    if (isset($_SESSION['Token_Medico'])) {
        $stmt = $conexion->prepare("UPDATE Sesiones_medicos SET Activo = 0 WHERE Token = :token");
        $stmt->execute([':token' => $_SESSION['Token_Medico']]);
    }

    session_unset();
    session_destroy();
}
?>
