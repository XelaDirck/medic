<?php
require_once("conexion.php"); // o usa la ruta correcta si está en otra carpeta

if ($conexion) {
    echo "<h2 style='color:green'>✅ Conexión exitosa a la base de datos.</h2>";
} else {
    echo "<h2 style='color:red'>❌ Error: No hay conexión.</h2>";
}
?>
