<?php
include '../PHP/conexion.php';
include '../PHP/sesion_medicos.php';

// Esto valida la sesión activa
verificarSesionMedico($conexion);
?>


<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Flemming - Dashboard</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="styles.css">
    
</head>
<body>
    <div class="d-flex flex-column flex-lg-row min-vh-100">
        <!-- Sidebar -->
        <nav id="sidebar" class="d-flex flex-column p-3">
            <a href="#" class="navbar-brand mb-4">MEDISYMEX</a>
            <ul class="nav nav-pills flex-column mb-auto">
                <li class="nav-item"><a href="#" class="nav-link active">Inicio</a></li>
                <li><a href="#" class="nav-link">Pacientes</a></li>
                <li><a href="#" class="nav-link">Citas</a></li>
                <li><a href="#" class="nav-link">Reportes</a></li>
                <li><a href="#" class="nav-link">Configuración</a></li>
            </ul>
            <hr>
            <div class="mt-auto">
                <a href="login_general.html" class="nav-link">Cerrar sesión</a>
            </div>
        </nav>

        <!-- Main Content -->
        <div id="main-content" class="flex-grow-1">
            <!-- Navbar superior -->
            <nav class="navbar navbar-expand-lg shadow-sm mb-4">
                <div class="container-fluid">
                    <span class="navbar-text fw-bold text-white">Bienvenido, <span id="username">Usuario</span></span>
                </div>
            </nav>

            <!-- Dashboard Cards -->
            <div class="row g-4">
                <div class="col-md-6 col-lg-3">
                    <div class="card shadow-sm p-3 text-center">
                        <h5 class="card-title">Pacientes Activos</h5>
                        <p class="card-text fs-4">120</p>
                        <a href="#" class="btn btn-success w-100">Ver Pacientes</a>
                    </div>
                </div>
                <div class="col-md-6 col-lg-3">
                    <div class="card shadow-sm p-3 text-center">
                        <h5 class="card-title">Citas Hoy</h5>
                        <p class="card-text fs-4">15</p>
                        <a href="#" class="btn btn-success w-100">Ver Citas</a>
                    </div>
                </div>
                <div class="col-md-6 col-lg-3">
                    <div class="card shadow-sm p-3 text-center">
                        <h5 class="card-title">Reportes Pendientes</h5>
                        <p class="card-text fs-4">3</p>
                        <a href="#" class="btn btn-success w-100">Ver Reportes</a>
                    </div>
                </div>
                <div class="col-md-6 col-lg-3">
                    <div class="card shadow-sm p-3 text-center">
                        <h5 class="card-title">Mensajes</h5>
                        <p class="card-text fs-4">5</p>
                        <a href="#" class="btn btn-success w-100">Leer Mensajes</a>
                    </div>
                </div>
            </div>

            <!-- Main Dashboard Content -->
            <section class="mt-5">
                <h3 class="fw-bold mb-3">Resumen General</h3>
                <p class="text-muted">Aquí podrás visualizar la información más relevante de tu área de trabajo, gestionar pacientes, citas, reportes y acceder a la configuración de tu cuenta.</p>
            </section>
            <!-- Citas y Calendario (agregado) -->
            <section class="mt-4">
                <h3 class="fw-bold mb-3">Citas Programadas</h3>

                <!-- Tabla de citas -->
                <div class="card p-3 mb-4">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle">
                            <thead class="table-primary text-center">
                                <tr>
                                    <th>Paciente</th>
                                    <th>Fecha</th>
                                    <th>Hora</th>
                                    <th>Motivo</th>
                                    <th>Estado</th>
                                </tr>
                            </thead>
                            <tbody class="text-center">
                                <tr>
                                    <td>Juan Pérez</td>
                                    <td>27/10/2025</td>
                                    <td>09:30 AM</td>
                                    <td>Chequeo general</td>
                                    <td><span class="badge bg-success">Confirmada</span></td>
                                </tr>
                                <tr>
                                    <td>María López</td>
                                    <td>27/10/2025</td>
                                    <td>11:00 AM</td>
                                    <td>Consulta de control</td>
                                    <td><span class="badge bg-warning text-dark">Pendiente</span></td>
                                </tr>
                                <tr>
                                    <td>Carlos Gómez</td>
                                    <td>28/10/2025</td>
                                    <td>10:15 AM</td>
                                    <td>Revisión de laboratorio</td>
                                    <td><span class="badge bg-success">Confirmada</span></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>

                <!-- Calendario estático (solo idea visual) -->
                <div class="card p-4">
                    <h5 class="fw-bold mb-3">Calendario de Citas (Ejemplo)</h5>
                    <div class="table-responsive">
                        <table class="table table-bordered text-center align-middle mb-0">
                            <thead class="table-light">
                                <tr>
                                    <th>L</th><th>M</th><th>Mi</th><th>J</th><th>V</th><th>S</th><th>D</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td></td><td>1</td><td>2</td><td>3</td><td>4</td><td>5</td><td>6</td>
                                </tr>
                                <tr>
                                    <td>7</td><td>8</td><td>9</td><td>10</td><td>11</td><td>12</td><td>13</td>
                                </tr>
                                <tr>
                                    <td>14</td><td>15</td><td>16</td><td>17</td><td>18</td><td>19</td><td>20</td>
                                </tr>
                                <tr>
                                    <td>21</td><td>22</td><td>23</td><td>24</td><td>25</td><td>26</td>
                                    <td class="table-primary">
                                        27<br><span class="badge bg-primary">2 citas</span>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="table-primary">
                                        28<br><span class="badge bg-primary">1 cita</span>
                                    </td>
                                    <td>29</td><td>30</td><td>31</td><td></td><td></td><td></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </section>

        </div>
    </div>

    <!-- Footer -->
    <footer>
        &copy; 2025 Clínica Flemming | <a href="#">Política de Privacidad</a> | <a href="#">Términos de Uso</a>
    </footer>

    <!-- Bootstrap JS Bundle -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
