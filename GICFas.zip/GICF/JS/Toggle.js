/* ============================
   TOGGLE NAVBAR (hamburguesa)
   ============================ */
const btn = document.querySelector('.nav-toggle');
const menu = document.querySelector('.nav-menu');

if (btn && menu) {
  btn.addEventListener('click', () => {
    const open = menu.classList.toggle('open');
    btn.classList.toggle('open', open);
    btn.setAttribute('aria-expanded', open ? 'true' : 'false');
  });
}

/* ============================================
   AUTO-ACTIVAR LINK DEL MENÚ SEGÚN LA PÁGINA
   ============================================ */
(function markActiveNav() {
  const current = new URL(window.location.href);
  const currentPath = current.pathname.replace(/\/+$/, '').toLowerCase();

  document.querySelectorAll('.nav-menu .link').forEach(a => {
    const href = a.getAttribute('href');
    if (!href) return;

    const target = new URL(href, current.origin);
    const targetPath = target.pathname.replace(/\/+$/, '').toLowerCase();

    if (targetPath === currentPath) {
      a.classList.add('active');
      a.setAttribute('aria-current', 'page');
    } else {
      a.classList.remove('active');
      a.removeAttribute('aria-current');
    }
  });
})();

/* ============================
      MODAL DE CERRAR SESIÓN
   ============================ */
function openLogoutModal(){
  const m = document.getElementById('logoutModal');
  if (m) m.style.display = 'flex';
}
function closeLogoutModal(){
  const m = document.getElementById('logoutModal');
  if (m) m.style.display = 'none';
}
function confirmLogout(){
  window.location.href = "fork_login_clinicas.html";
}

window.openLogoutModal  = openLogoutModal;
window.closeLogoutModal = closeLogoutModal;
window.confirmLogout    = confirmLogout;


