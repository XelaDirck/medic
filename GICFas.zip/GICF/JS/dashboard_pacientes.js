document.addEventListener("DOMContentLoaded", () => {
  const currentPage = document.body.dataset.page;  // Usar el atributo data-page para identificar la página activa

  switch (currentPage) {
    case 'paciente-resumen':
      initPacienteResumen();
      break;
    case 'paciente-citas':
      initPacienteCitas();
      break;
    case 'paciente-expediente':
      initPacienteExpediente();
      break;
    case 'paciente-estudios':
      initPacienteEstudios();
      break;
    case 'paciente-tratamiento':
      initPacienteTratamiento();
      break;
    case 'paciente-mensajes':
      initPacienteMensajes();
      break;
    case 'paciente-perfil':
      initPacientePerfil();
      break;
    default:
      console.log("Página no reconocida.");
  }
});

/* =========================================================
   =============  RESUMEN DEL PACIENTE  ====================
========================================================= */
function initPacienteResumen() {
  const box = document.getElementById("pacienteResumen");
  if (!box) return;

  console.log("✔ initPacienteResumen() activo");

  // Obtener datos del backend (PHP)
  fetch('http://localhost/api/getResumenPaciente.php')
    .then(response => response.json())
    .then(datos => {
      box.innerHTML = `
        <div class="card-body">
          <h5 class="fw-semibold">${datos.nombre}</h5>
          <p class="text-muted small mb-1">Próximas citas: ${datos.citasProximas}</p>
          <p class="small mb-1">Último estudio: ${datos.ultEstudio}</p>
          <p class="small mb-1">Tratamiento activo: ${datos.tratamiento}</p>
          <p class="small">Mensajes nuevos: ${datos.mensajes}</p>
        </div>
      `;
    })
    .catch(error => console.error('Error al cargar el resumen del paciente:', error));
}

/* =========================================================
   =============  MIS CITAS (PACIENTE) =====================
========================================================= */
function initPacienteCitas() {
  const tabla = document.getElementById("tablaCitasPaciente");
  if (!tabla) return;

  console.log("✔ initPacienteCitas() activo");

  fetch('http://localhost/api/getCitasPaciente.php')
    .then(response => response.json())
    .then(citas => {
      renderTabla(citas);
    })
    .catch(error => console.error('Error al cargar las citas:', error));

  function renderTabla(citas) {
    const tbody = tabla.querySelector("tbody");
    tbody.innerHTML = "";

    if (!citas.length) {
      tbody.innerHTML = `<tr><td colspan="5" class="text-center text-muted small py-3">No tienes citas registradas.</td></tr>`;
      return;
    }

    citas.forEach(c => {
      tbody.innerHTML += `
        <tr>
          <td>${c.fecha}</td>
          <td>${c.hora}</td>
          <td>${c.medico}</td>
          <td>${c.motivo}</td>
          <td><span class="badge text-bg-${colorEstado(c.estado)}">${c.estado}</span></td>
        </tr>
      `;
    });
  }

  function colorEstado(e) {
    e = e.toLowerCase();
    if (e === "confirmada") return "primary";
    if (e === "pendiente") return "warning";
    if (e === "cancelada") return "danger";
    if (e === "completada") return "success";
    return "secondary";
  }
}

/* =========================================================
   =============  EXPEDIENTE DEL PACIENTE ===================
========================================================= */
function initPacienteExpediente() {
  const cont = document.getElementById("expedientePaciente");
  if (!cont) return;

  console.log("✔ initPacienteExpediente() activo");

  const pacienteId = 1; // Simulamos un paciente id (esto debe ser dinámico desde la sesión)
  fetch(`http://localhost/api/getExpedientePaciente.php?paciente_id=${pacienteId}`)
    .then(response => response.json())
    .then(demo => {
      cont.innerHTML = `
        <p><strong>Vacunas:</strong></p>
        <ul>${demo.vacunas.map(v => `<li>${v}</li>`).join("")}</ul>

        <p><strong>Alergias:</strong></p>
        <ul>${demo.alergias.map(a => `<li>${a}</li>`).join("")}</ul>

        <p><strong>Antecedentes clínicos:</strong></p>
        <p>${demo.antecedentes}</p>

        <p class="text-muted small mt-3">
          Última actualización: ${demo.ultimaActualizacion}
        </p>
      `;
    })
    .catch(error => console.error('Error al cargar expediente:', error));
}

/* =========================================================
   =============  ESTUDIOS Y RESULTADOS =====================
========================================================= */
function initPacienteEstudios() {
  const lista = document.getElementById("listaEstudiosPaciente");
  if (!lista) return;

  console.log("✔ initPacienteEstudios() activo");

  fetch('http://localhost/api/getEstudiosPaciente.php')
    .then(response => response.json())
    .then(estudios => {
      lista.innerHTML = estudios.map(e => `
        <div class="list-group-item d-flex justify-content-between">
          <div>
            <strong>${e.estudio}</strong><br>
            <small class="text-muted">${e.fecha}</small>
          </div>
          <span class="badge text-bg-success">${e.estado}</span>
        </div>
      `).join("");
    })
    .catch(error => console.error('Error al cargar los estudios:', error));
}

/* =========================================================
   =============  TRATAMIENTO / MEDICACIÓN =================
========================================================= */
function initPacienteTratamiento() {
  const box = document.getElementById("tratamientoPaciente");
  if (!box) return;

  console.log("✔ initPacienteTratamiento() activo");

  const tratamiento = [
    { med: "Losartán 50mg", dosis: "1 diaria", horario: "8:00 AM" },
    { med: "Vitamina D 2000 IU", dosis: "1 diaria", horario: "12:00 PM" }
  ];

  box.innerHTML = tratamiento.map(t => `
    <div class="border rounded p-2 mb-2">
      <strong>${t.med}</strong><br>
      <small>${t.dosis} — ${t.horario}</small>
    </div>
  `).join("");
}

/* =========================================================
   =============  MENSAJES DEL PACIENTE =====================
========================================================= */
function initPacienteMensajes() {
  const lista = document.getElementById("mensajesPaciente");
  if (!lista) return;

  console.log("✔ initPacienteMensajes() activo");

  const mensajes = [
    { de: "Dra. López", asunto: "Resultados disponibles", fecha: "2025-11-15" },
    { de: "Dr. Ramírez", asunto: "Recordatorio de cita", fecha: "2025-11-10" }
  ];

  lista.innerHTML = mensajes.map(m => `
    <div class="list-group-item">
      <strong>${m.asunto}</strong><br>
      <small class="text-muted">${m.de} — ${m.fecha}</small>
    </div>
  `).join("");
}
