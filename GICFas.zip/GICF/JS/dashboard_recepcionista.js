document.addEventListener("DOMContentLoaded", () => {
  const currentPage = document.body.dataset.page;  // Usar el atributo data-page para identificar la página activa

  switch (currentPage) {
    case 'recep-resumen':
      initRecepResumen();
      break;
    case 'recep-citas':
      initRecepCitas();
      break;
    case 'recep-pacientes':
      initRecepPacientes();
      break;
    case 'recep-mensajes':
      initRecepMensajes();
      break;
    case 'recep-perfil':
      initRecepPerfil();
      break;
    default:
      console.warn("Página de recepción sin inicializador específico:", currentPage);
  }
});

/* =========================== 1. RESUMEN RECEPCIONISTA ========================== */
function initRecepResumen() {
  console.log("Init Recepción - Resumen");

  // KPIs desde el backend (PHP)
  const kCitasHoy = document.getElementById("kpiRecepCitasHoy");
  const kEspera = document.getElementById("kpiRecepEspera");
  const kPorConfirmar = document.getElementById("kpiRecepPorConfirmar");
  const kCanceladas = document.getElementById("kpiRecepCanceladas");

  fetch('http://localhost/api/getResumenRecepcionista.php')
    .then(response => response.json())
    .then(datos => {
      if (kCitasHoy) kCitasHoy.textContent = datos.citasHoy;
      if (kEspera) kEspera.textContent = datos.pacientesEnEspera;
      if (kPorConfirmar) kPorConfirmar.textContent = datos.citasPorConfirmar;
      if (kCanceladas) kCanceladas.textContent = datos.citasCanceladas;
    })
    .catch(error => console.error('Error al cargar el resumen de recepción:', error));

  // Sala de espera desde el backend (PHP)
  const sala = document.getElementById("listaRecepSalaEspera");
  if (sala) {
    fetch('http://localhost/api/getSalaEspera.php')
      .then(response => response.json())
      .then(pacientes => {
        sala.innerHTML = pacientes.map(p => `
          <div class="list-group-item d-flex justify-content-between align-items-center">
            <div>
              <strong>${p.nombre}</strong>
              <div class="small text-muted">Motivo: ${p.motivo}</div>
            </div>
            <span class="badge text-bg-primary">Turno ${p.turno}</span>
          </div>
        `).join('');
      })
      .catch(error => console.error('Error al cargar la sala de espera:', error));
  }

  // Recordatorios desde el backend (PHP)
  const rec = document.getElementById("listaRecepRecordatorios");
  if (rec) {
    fetch('http://localhost/api/getRecordatoriosRecepcion.php')
      .then(response => response.json())
      .then(recordatorios => {
        rec.innerHTML = recordatorios.map(r => `
          <ul class="list-unstyled mb-0">
            <li class="mb-2">
              <i class="bi bi-bell me-1 text-warning"></i>
              ${r.descripcion}
            </li>
          </ul>
        `).join('');
      })
      .catch(error => console.error('Error al cargar los recordatorios:', error));
  }
}

/* =========================== 2. CITAS RECEPCIONISTA ========================== */
function initRecepCitas() {
  console.log("Init Recepción - Citas");

  const form = document.getElementById("formNuevaRecepCita");
  if (form) {
    form.addEventListener("submit", (e) => {
      e.preventDefault();
      fetch('http://localhost/api/guardarCitaRecepcionista.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          paciente: document.getElementById("nuevaRecepPaciente").value,
          medico: document.getElementById("nuevaRecepMedico").value,
          fecha: document.getElementById("nuevaRecepFecha").value,
          hora: document.getElementById("nuevaRecepHora").value,
          motivo: document.getElementById("nuevaRecepMotivo").value,
          estado: document.getElementById("nuevaRecepEstado").value
        })
      })
      .then(response => response.json())
      .then(data => {
        alert("Cita registrada exitosamente.");
        form.reset();
      })
      .catch(error => console.error('Error al registrar la cita:', error));
    });
  }

  const btnAplicar = document.getElementById("btnRecepAplicarFiltros");
  if (btnAplicar) {
    btnAplicar.addEventListener("click", () => {
      console.log("Aplicar filtros de citas");
    });
  }

  const btnLimpiar = document.getElementById("btnRecepLimpiarFiltros");
  if (btnLimpiar) {
    btnLimpiar.addEventListener("click", () => {
      console.log("Limpiar filtros de citas");
    });
  }
}

/* =========================== 3. PACIENTES RECEPCIONISTA ========================== */
function initRecepPacientes() {
  console.log("Init Recepción - Pacientes");

  const formAlta = document.getElementById("formRecepAltaPaciente");
  if (formAlta) {
    formAlta.addEventListener("submit", (e) => {
      e.preventDefault();

      fetch('http://localhost/api/guardarPacienteRecepcionista.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          nombre: document.getElementById("altaPacNombre").value,
          documento: document.getElementById("altaPacDocumento").value,
          telefono: document.getElementById("altaPacTelefono").value,
          correo: document.getElementById("altaPacCorreo").value,
          estadoCivil: document.getElementById("altaPacEstadoCivil").value,
          nacionalidad: document.getElementById("altaPacNacionalidad").value,
          domicilio: document.getElementById("altaPacDomicilio").value,
          medico: document.getElementById("altaPacMedicoResp").value,
          etiqueta: document.getElementById("altaPacEtiqueta").value
        })
      })
      .then(response => response.json())
      .then(data => {
        alert("Paciente registrado exitosamente.");
        formAlta.reset();
      })
      .catch(error => console.error('Error al registrar paciente:', error));
    });
  }
}

/* =========================== 4. MENSAJES RECEPCIONISTA ========================== */
function initRecepMensajes() {
  console.log("Init Recepción - Mensajes");

  const form = document.getElementById("formRecepEnviarMensaje");
  if (form) {
    form.addEventListener("submit", (e) => {
      e.preventDefault();
      const txt = document.getElementById("recepMensajeTexto");
      if (!txt) return;
      if (!txt.value.trim()) {
        alert("Escribe un mensaje antes de enviar.");
        return;
      }

      fetch('http://localhost/api/enviarMensajeRecepcionista.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          mensaje: txt.value
        })
      })
      .then(response => response.json())
      .then(data => {
        alert("Mensaje enviado.");
        txt.value = "";
      })
      .catch(error => console.error('Error al enviar el mensaje:', error));
    });
  }
}

/* =========================== 5. PERFIL RECEPCIONISTA ========================== */
function initRecepPerfil() {
  console.log("Init Recepción - Perfil");

  const formPerfil = document.getElementById("formRecepPerfil");
  if (formPerfil) {
    formPerfil.addEventListener("submit", (e) => {
      e.preventDefault();
      alert("Perfil actualizado (demo).");
    });
  }

  const formPass = document.getElementById("formRecepPassword");
  if (formPass) {
    formPass.addEventListener("submit", (e) => {
      e.preventDefault();
      alert("Contraseña actualizada (demo).");
      formPass.reset();
    });
  }
}
