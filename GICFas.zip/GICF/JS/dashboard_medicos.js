/* =========================================================
   DASHBOARD MÉDICO – SISTEMA MODULAR
========================================================= */
document.addEventListener("DOMContentLoaded", () => {
  // Detecta el dashboard activo y ejecuta las funciones necesarias
  const currentPage = document.body.id; // Usar un ID único en cada página para identificarlas

  switch (currentPage) {
    case 'dashboard_medicos':
      initResumenMedico();
      break;
    case 'dashboard_medicos_citas':
      initCitasMedico();
      break;
    case 'dashboard_medicos_pacientes':
      initPacientesMedico();
      break;
    case 'dashboard_medicos_expedientes':
      initExpedientesMedico();
      break;
    case 'dashboard_medicos_mensajes':
      initMensajesMedico();
      break;
    default:
      console.log("Página no reconocida.");
  }
});

/* =========================================================
   MÓDULO: RESUMEN MÉDICO
========================================================= */
function initResumenMedico() {
  console.log("✔ Resumen del Médico");

  // Código para cargar KPIs, citas y pacientes del resumen
  fetch('http://localhost/api/getKPIs.php')
    .then(response => response.json())
    .then(data => {
      // Actualizar la UI con los datos
      document.getElementById('kpiCitasHoyMed').textContent = data.citas_hoy;
      document.getElementById('kpiPacActivosMed').textContent = data.pacientes_activos;
      document.getElementById('kpiResultadosPend').textContent = data.resultados_pendientes;
      document.getElementById('kpiAlertas').textContent = data.alertas;
    })
    .catch(error => console.error('Error al cargar el resumen:', error));
}

/* =========================================================
   MÓDULO: CITAS DEL MÉDICO
========================================================= */
function initCitasMedico() {
  const tabla = document.getElementById("tablaCitas");
  const formFiltros = document.getElementById("formFiltrosCitas");

  if (!tabla) return; // No estamos en la página de CITAS

  console.log("✔ Citas del Médico");

  // Obtener citas del médico desde la base de datos
  fetch('http://localhost/api/getCitasMedico.php')
    .then(response => response.json())
    .then(citas => {
      renderTabla(citas);
    })
    .catch(error => console.error('Error al cargar las citas:', error));

  function renderTabla(citas) {
    const tbody = tabla.querySelector("tbody");
    tbody.innerHTML = ""; // Limpiar tabla antes de añadir datos

    if (!citas.length) {
      tbody.innerHTML = `<tr><td colspan="6" class="text-center">No hay citas registradas.</td></tr>`;
      return;
    }

    citas.forEach(c => {
      const tr = document.createElement("tr");
      tr.innerHTML = `
        <td>${c.fecha}</td>
        <td>${c.hora}</td>
        <td>${c.paciente}</td>
        <td>${c.motivo}</td>
        <td><span class="badge text-bg-${colorEstadoCita(c.estado)}">${c.estado}</span></td>
        <td class="text-end">
          <button class="btn btn-sm btn-outline-primary"><i class="bi bi-eye"></i></button>
          <button class="btn btn-sm btn-outline-secondary"><i class="bi bi-pencil"></i></button>
          <button class="btn btn-sm btn-outline-danger"><i class="bi bi-x"></i></button>
        </td>
      `;
      tbody.appendChild(tr);
    });
  }

  function colorEstadoCita(estado) {
    switch (estado.toLowerCase()) {
      case 'confirmada': return 'primary';
      case 'pendiente': return 'warning';
      case 'cancelada': return 'danger';
      case 'completada': return 'success';
      default: return 'secondary';
    }
  }

  // Filtrado de citas
  if (formFiltros) {
    formFiltros.addEventListener("input", () => {
      const fFecha = document.getElementById("filtroFecha").value;
      const fHora = document.getElementById("filtroHora").value;
      const fPaciente = document.getElementById("filtroPaciente").value.toLowerCase();
      const fEstado = document.getElementById("filtroEstado").value;

      fetch(`http://localhost/api/getCitasMedico.php?fecha=${fFecha}&hora=${fHora}&paciente=${fPaciente}&estado=${fEstado}`)
        .then(response => response.json())
        .then(citas => renderTabla(citas))
        .catch(error => console.error('Error al filtrar las citas:', error));
    });
  }
}

/* =========================================================
   MÓDULO: PACIENTES DEL MÉDICO
========================================================= */
function initPacientesMedico() {
  const tabla = document.getElementById("tablaPacientes");

  if (!tabla) return; // No estamos en la página de PACIENTES

  console.log("✔ Pacientes del Médico");

  // Obtener pacientes del médico desde la base de datos
  fetch('http://localhost/api/getPacientesMedico.php')
    .then(response => response.json())
    .then(pacientes => {
      const tbody = tabla.querySelector("tbody");
      pacientes.forEach(p => {
        const tr = document.createElement("tr");
        tr.innerHTML = `
          <td>${p.nombre}</td>
          <td>${p.edad}</td>
          <td>${p.sexo}</td>
          <td class="text-end">
            <button class="btn btn-sm btn-outline-primary"><i class="bi bi-eye"></i></button>
            <button class="btn btn-sm btn-outline-secondary"><i class="bi bi-pencil"></i></button>
          </td>
        `;
        tbody.appendChild(tr);
      });
    })
    .catch(error => console.error('Error al cargar pacientes:', error));
}

/* =========================================================
   MÓDULO: EXPEDIENTES MÉDICOS DEL PACIENTE
========================================================= */
function initExpedientesMedico() {
  const vista = document.getElementById("expedienteViewer");
  if (!vista) return; // No estamos en expedientes

  console.log("✔ Expedientes del Médico");

  const params = new URLSearchParams(location.search);
  const idPaciente = params.get("paciente");

  if (!idPaciente) return;

  fetch(`http://localhost/api/getExpedientesMedico.php?paciente_id=${idPaciente}`)
    .then(response => response.json())
    .then(expediente => {
      if (expediente) {
        document.getElementById("expPacienteInfo").innerHTML = `
          <h5 class="fw-semibold mb-1">${expediente.nombre}</h5>
          <small class="text-muted">Última actualización: ${expediente.ultimaActualizacion}</small>
        `;

        document.getElementById("expedienteContenido").innerHTML = `
          <h6>Historia clínica</h6>
          <p>${expediente.historiaClinica}</p>
          <h6>Alergias</h6>
          <ul>${expediente.alergias.map(a => `<li>${a}</li>`).join("")}</ul>
          <h6>Medicamentos</h6>
          <ul>${expediente.medicamentos.map(m => `<li>${m}</li>`).join("")}</ul>
        `;
      }
    })
    .catch(error => console.error('Error al cargar expediente médico:', error));
}

/* =========================================================
   MÓDULO: MENSAJES DEL MÉDICO
========================================================= */
function initMensajesMedico() {
  console.log("✔ Mensajes del Médico");
  // Lógica para cargar y enviar mensajes
}
