/* ==========================
   CONFIGURACIÓN DEL CALENDARIO
============================ */

// ROL dinámico según el usuario loggeado
let rolActual = "medico";  
// Valores posibles: "medico", "recepcionista", "familiar", "paciente"

/* ====== Datos demo (puedes reemplazar por tu backend) ====== */
const citasDemo = [
  { fecha: "2025-11-18", hora: "10:00", paciente: "Juan Pérez", motivo: "Consulta general", visiblePara: ["medico","recepcionista"] },
  { fecha: "2025-11-18", hora: "12:00", paciente: "Ana Gómez", motivo: "Chequeo", visiblePara: ["medico","paciente"] },
  { fecha: "2025-11-19", hora: "09:00", paciente: "Luis Torres", motivo: "Rayos X", visiblePara: ["medico","familiar"] },
  { fecha: "2025-11-21", hora: "08:00", paciente: "Mario Ruiz", motivo: "Vacunas", visiblePara: ["medico","recepcionista"] }
];

/* ==========================
      UTILIDADES FECHAS
============================ */
function isoFromDate(d) {
  return d.toISOString().split("T")[0];
}

function dateFromISO(iso) {
  return new Date(iso + "T00:00:00");
}

const meses = [
  "enero","febrero","marzo","abril","mayo","junio",
  "julio","agosto","septiembre","octubre","noviembre","diciembre"
];

/* ==========================
      FILTRO POR ROL
============================ */
function filtrarCitasPorRol(lista, rol) {
  return lista.filter(c => c.visiblePara.includes(rol));
}

/* ==========================
   CALENDARIO DEL DÍA
============================ */
function initCalendarioDia() {
  const input = document.getElementById("calInputDate");
  const btnPrev = document.getElementById("btnCalPrev");
  const btnNext = document.getElementById("btnCalNext");
  const btnHoy = document.getElementById("btnCalHoy");
  const fechaLegible = document.getElementById("calFechaLegible");
  const listaCitas = document.getElementById("calListaCitas");

  if (!input) return;

  let selected = new Date();

  function render() {
    const iso = isoFromDate(selected);
    input.value = iso;

    fechaLegible.textContent =
      `${selected.getDate()} de ${meses[selected.getMonth()]} ${selected.getFullYear()}`;

    listaCitas.innerHTML = "";

    const citas = filtrarCitasPorRol(citasDemo, rolActual)
      .filter(c => c.fecha === iso);

    if (citas.length === 0) {
      listaCitas.innerHTML = `<div class="list-group-item text-muted">No hay citas este día.</div>`;
    } else {
      citas.forEach(c => {
        const item = document.createElement("div");
        item.className = "list-group-item";
        item.innerHTML = `
          <div class="d-flex justify-content-between">
            <div>
              <strong>${c.paciente}</strong>
              <div class="small text-muted">${c.motivo}</div>
            </div>
            <span class="badge text-bg-primary">${c.hora}</span>
          </div>`;
        listaCitas.appendChild(item);
      });
    }
  }

  render();

  input.addEventListener("change", () => {
    selected = dateFromISO(input.value);
    render();
  });

  btnPrev.addEventListener("click", () => {
    selected.setDate(selected.getDate() - 1);
    render();
  });

  btnNext.addEventListener("click", () => {
    selected.setDate(selected.getDate() + 1);
    render();
  });

  btnHoy.addEventListener("click", () => {
    selected = new Date();
    render();
  });
}

/* ==========================
   CALENDARIO MENSUAL (7xN)
============================ */
function initCalendarioMensual() {
  const monthLabel = document.getElementById("monthLabel");
  const grid = document.getElementById("monthCalendarGrid");
  const btnPrev = document.getElementById("btnMonthPrev");
  const btnNext = document.getElementById("btnMonthNext");

  if (!monthLabel || !grid) return;

  let currentMonth = new Date();

  function renderMonth() {
    const year = currentMonth.getFullYear();
    const month = currentMonth.getMonth();

    monthLabel.textContent =
      `${meses[month].charAt(0).toUpperCase() + meses[month].slice(1)} ${year}`;

    const citas = filtrarCitasPorRol(citasDemo, rolActual);

    const counts = {};
    citas.forEach(c => {
      counts[c.fecha] = (counts[c.fecha] || 0) + 1;
    });

    grid.innerHTML = "";

    const first = new Date(year, month, 1);
    const days = new Date(year, month + 1, 0).getDate();

    const offset = (first.getDay() + 6) % 7; // mover domingo al final

    // Celdas vacías previas
    for (let i = 0; i < offset; i++) {
      const blank = document.createElement("div");
      blank.className = "month-cell month-cell--empty";
      grid.appendChild(blank);
    }

    // Días del mes
    for (let d = 1; d <= days; d++) {
      const date = new Date(year, month, d);
      const iso = isoFromDate(date);
      const count = counts[iso] || 0;

      const today =
        date.toDateString() === new Date().toDateString()
          ? " month-cell--today"
          : "";

      const cell = document.createElement("div");
      cell.className = "month-cell" + today;

      cell.innerHTML = `
        <span class="month-number">${d}</span>
        <span class="month-count">
          ${count ? `${count} cita${count > 1 ? "s" : ""}` : "&nbsp;"}
        </span>
      `;

      grid.appendChild(cell);
    }
  }

  renderMonth();

  btnPrev.addEventListener("click", () => {
    currentMonth.setMonth(currentMonth.getMonth() - 1);
    renderMonth();
  });

  btnNext.addEventListener("click", () => {
    currentMonth.setMonth(currentMonth.getMonth() + 1);
    renderMonth();
  });
}

/* ==========================
   INICIALIZAR TODO
============================ */
document.addEventListener("DOMContentLoaded", () => {
  initCalendarioDia();
  initCalendarioMensual();
});
